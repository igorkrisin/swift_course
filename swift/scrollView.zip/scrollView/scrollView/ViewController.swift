//
//  ViewController.swift
//  scrollView
//
//  Created by Игорь Крысин on 20.12.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

